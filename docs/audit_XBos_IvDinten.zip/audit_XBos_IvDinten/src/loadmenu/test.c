#include <stdio.h>

int main(int argc, char** argv) {
	int value = 0;
	value = value ? 0 : 1;
	printf("%d\n",value);
	return 0;
}
