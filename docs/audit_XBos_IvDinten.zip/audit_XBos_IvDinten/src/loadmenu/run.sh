#!/bin/sh

propeller-load -bGAMEBLADE -r -S -t include/sd_cache_menu.elf
