. ${srcdir}/emulparams/pjelf.sh
OUTPUT_FORMAT="elf32-pjl"
