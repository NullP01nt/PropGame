. ${srcdir}/emulparams/elf32_tic6x_le.sh
OUTPUT_FORMAT="elf32-tic6x-be"
