. ${srcdir}/emulparams/armelf.sh
OUTPUT_FORMAT="elf32-bigarm"
