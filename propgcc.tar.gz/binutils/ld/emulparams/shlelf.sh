. ${srcdir}/emulparams/shelf.sh
OUTPUT_FORMAT="elf32-shl"
