MACHINE=
SCRIPT_NAME=xstormy16
TEMPLATE_NAME=elf32
EXTRA_EM_FILE=needrelax
OUTPUT_FORMAT="elf32-xstormy16"
# See also `include/elf/xstormy16.h'
ARCH=xstormy16
ALIGNMENT=2
ENTRY=_start
EMBEDDED=yes
NOP=0


