. ${srcdir}/emulparams/armelf_linux_eabi.sh
OUTPUT_FORMAT="elf32-bigarm"
