. ${srcdir}/emulparams/h8300elf.sh
ARCH="h8300:h8300h"
STACK_ADDR=0x2fefc
