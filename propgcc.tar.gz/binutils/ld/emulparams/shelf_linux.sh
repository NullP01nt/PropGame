. ${srcdir}/emulparams/shlelf_linux.sh
OUTPUT_FORMAT="elf32-shbig-linux"
