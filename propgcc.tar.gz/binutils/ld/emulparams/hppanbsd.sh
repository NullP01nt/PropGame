# If you change this file, please also look at files which source this one:
# hppaobsd.sh

. ${srcdir}/emulparams/hppalinux.sh

OUTPUT_FORMAT="elf32-hppa-netbsd"
