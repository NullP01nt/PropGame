SCRIPT_NAME=alpha
OUTPUT_FORMAT="ecoff-littlealpha"
ARCH=alpha
