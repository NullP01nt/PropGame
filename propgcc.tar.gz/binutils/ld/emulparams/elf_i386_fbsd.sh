. ${srcdir}/emulparams/elf_i386.sh
. ${srcdir}/emulparams/elf_fbsd.sh
OUTPUT_FORMAT="elf32-i386-freebsd"
