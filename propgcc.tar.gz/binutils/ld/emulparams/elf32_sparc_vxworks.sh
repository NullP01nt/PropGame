. ${srcdir}/emulparams/elf32_sparc.sh
OUTPUT_FORMAT="elf32-sparc-vxworks"
unset DATA_PLT
. ${srcdir}/emulparams/vxworks.sh
