void foo ();

void
ref ()
{
  foo ();
}
