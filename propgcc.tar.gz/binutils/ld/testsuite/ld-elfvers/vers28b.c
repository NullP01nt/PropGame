#pragma weak foo

void foo () {}
