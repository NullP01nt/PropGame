extern int x;
void foo (void)
{
  x = 24;
}
