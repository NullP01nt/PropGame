int
main()
{
  return a(1) + b(1);
}
