void foo () {}
asm (".hidden foo");
