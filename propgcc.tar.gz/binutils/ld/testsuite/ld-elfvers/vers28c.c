extern void foo ();

void
bar ()
{
  foo ();
}
