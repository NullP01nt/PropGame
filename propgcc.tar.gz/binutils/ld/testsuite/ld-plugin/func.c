
extern int retval;

int func (void)
{
  return retval;
}
