__declspec(dllimport) int dll_func (void);

int
main()
{
  dll_func ();
  return 0;
}
