struct foo_s
{
  int foo;
};

extern void doprintf (void);
