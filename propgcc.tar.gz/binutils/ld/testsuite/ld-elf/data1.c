#include "data1.h"

char a1[1] __attribute__ ((aligned (ALIGNMENT1))) = { 10 };
char a2[2] __attribute__ ((aligned (ALIGNMENT2)));
char a3[3] __attribute__ ((aligned (ALIGNMENT3)));
char a4[4] __attribute__ ((aligned (ALIGNMENT4)));
