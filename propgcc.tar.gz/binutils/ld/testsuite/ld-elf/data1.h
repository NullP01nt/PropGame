#define ALIGNMENT1 0x800
#define ALIGNMENT2 0x400
#define ALIGNMENT3 0x200
#define ALIGNMENT4 0x100

extern char a1[1];
extern char a2[2];
extern char a3[3];
extern char a4[4];
