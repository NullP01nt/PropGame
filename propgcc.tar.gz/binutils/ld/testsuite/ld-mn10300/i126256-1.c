void
sub0 (int i)
{
  extern int sub (int);

  sub (i);
}
