int
sub (int i)
{
  return i + 10;
}
