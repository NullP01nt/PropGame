#pragma weak foo

extern void foo ();

void
foo ()
{
}
