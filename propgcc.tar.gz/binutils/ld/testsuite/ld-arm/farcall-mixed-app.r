
tmpdir/farcall-mixed-app.*:     file format elf32-(little|big)arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
.* R_ARM_COPY        data_obj
.* R_ARM_JUMP_SLOT   lib_func2
.* R_ARM_JUMP_SLOT   lib_func1


